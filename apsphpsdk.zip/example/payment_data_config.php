<?php

return  [
    'merchant_reference'=> 'O-00001-'.rand(1000, 99999),
    'amount'            => 1500.00,
    'currency'          => 'AED',
    'language'          => 'en',
    'customer_email'    => 'test@aps.com',

    'order_description' => 'Test product 1',
];
