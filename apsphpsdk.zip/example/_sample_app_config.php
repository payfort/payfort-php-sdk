<?php

return [
    'base_url'      => 'http://aps.localhost:8080/',
];