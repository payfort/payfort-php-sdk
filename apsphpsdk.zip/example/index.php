<?php
include '_header.php';
?>
<h1>Amazon Payment Services</h1>
<h2>PHP SDK</h2>
<h3>Sample Application</h3>
<?php
include '_footer.php';
?>
