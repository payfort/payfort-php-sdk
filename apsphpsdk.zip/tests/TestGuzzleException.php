<?php

namespace Tests;

use GuzzleHttp\Exception\GuzzleException;

class TestGuzzleException extends \Exception implements GuzzleException
{

}